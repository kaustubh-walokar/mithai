#!/usr/bin/env bash
mosquitto -c mosquitto.conf